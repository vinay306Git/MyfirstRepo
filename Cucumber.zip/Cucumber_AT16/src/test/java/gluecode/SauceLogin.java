package gluecode;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SauceLogin 
{
	WebDriver wd = new FirefoxDriver();
	
	@Given("The User navigate to the Sauce demo site")
	public void the_user_navigate_to_the_sauce_demo_site() 
	{
		wd.get("https://www.saucedemo.com/");
	    wd.manage().window().maximize();
	    wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	@When("The user logs in with username {string} and Password {string}")
	public void the_user_logs_in_with_username_and_password(String username, String password) 
	{
		wd.findElement(By.id("user-name")).sendKeys(username);
		wd.findElement(By.id("password")).sendKeys(password);
		 wd.findElement(By.id("login-button")).click();
	}

	@When("User add a product to the cart")
	public void user_add_a_product_to_the_cart() throws InterruptedException 
	{
		WebElement home =	wd.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[2]/div"));
		System.out.println(home.isDisplayed());
		System.out.println(home.getText());
		Thread.sleep(2000);
		wd.findElement(By.name("add-to-cart-sauce-labs-bike-light")).click();
		wd.findElement(By.name("add-to-cart-sauce-labs-bolt-t-shirt")).click();
		wd.findElement(By.linkText("shopping_cart_link")).click();
		Thread.sleep(2000);
		wd.findElement(By.name("checkout")).click();
		Thread.sleep(2000);
	}

	@When("the user proceeds to checkout with Firstname {string}, Last name {string} and Postal Pin {string}")
	public void the_user_proceeds_to_checkout_with_firstname_last_name_and_postal_pin(String firstname, String lastname, String pincode) throws InterruptedException 
	{
		wd.findElement(By.name("firstName")).sendKeys(firstname);
		wd.findElement(By.name("lastName")).sendKeys(lastname);
		wd.findElement(By.name("postalCode")).sendKeys(pincode);
		Thread.sleep(2000);
		wd.findElement(By.name("continue")).click();
		Thread.sleep(2000);
	   
	}

	@Then("user see the checkout confirmation page")
	public void user_see_the_checkout_confirmation_page() throws InterruptedException 
	{
	  WebElement confirm =  wd.findElement(By.xpath("/html/body/div/div/div/div[1]/div[2]/span"));
	  Thread.sleep(2000);
	  System.out.println(confirm.isDisplayed());
	  System.out.println(confirm.getText());
	  Thread.sleep(2000);
	  wd.findElement(By.name("finish")).click();
	  Thread.sleep(2000);
	  wd.quit();
	}

}
