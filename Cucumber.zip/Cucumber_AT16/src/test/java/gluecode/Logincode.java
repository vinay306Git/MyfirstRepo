package gluecode;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Logincode 
{
	WebDriver wd;
	
	@Given("Browser must be open")
	public void browser_must_be_open() 
	{
		wd = new FirefoxDriver();
		wd.get("https://www.saucedemo.com/");
	    wd.manage().window().maximize();
	    wd.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	@When("Enter Username and Password")
	public void enter_username_and_password() 
	{
	   wd.findElement(By.name("user-name")).sendKeys("standard_user");
	   wd.findElement(By.name("password")).sendKeys("secret_sauce");
	}

	@When("click on Login")
	public void click_on_login() 
	{
	    wd.findElement(By.name("login-button")).click();
	}

	@Then("HomePage should be displayed")
	public void home_page_should_be_displayed() 
	{
	WebElement home =	wd.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[2]/div"));
	System.out.println(home.isDisplayed());
	System.out.println(home.getText());
	 
	}

	@Then("Application should be quit")
	public void application_should_be_quit() 
	{
	    wd.quit();
	}

}
